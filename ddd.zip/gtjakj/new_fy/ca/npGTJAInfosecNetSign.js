//@line 2 "npInfosecNetSign.dll_plugins.js"
pref("dom.ipc.plugins.enabled.npGTJAInfosecNetSign.dll", false);