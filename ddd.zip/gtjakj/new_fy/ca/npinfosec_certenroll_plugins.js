//@line 2 "icbc_infosec_certenroll_plugins.js"
pref("dom.ipc.plugins.enabled.npinfosec_certenroll.dll", false);